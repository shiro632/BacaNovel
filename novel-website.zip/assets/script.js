document.getElementById("toggle-mode").addEventListener("click", function () {
    document.body.classList.toggle("dark-mode");
    this.textContent = document.body.classList.contains("dark-mode") ? "Mode Terang" : "Mode Gelap";
});

document.getElementById("increase-font").addEventListener("click", function () {
    document.querySelector(".chapter-content").style.fontSize = "larger";
});

document.getElementById("decrease-font").addEventListener("click", function () {
    document.querySelector(".chapter-content").style.fontSize = "smaller";
});

document.getElementById("mark-read").addEventListener("click", function () {
    alert("Chapter ini ditandai sebagai selesai!");
});

document.getElementById("submit-comment").addEventListener("click", function () {
    let input = document.getElementById("comment-input").value;
    if (input.trim() === "") return;

    let commentList = document.getElementById("comment-list");
    let newComment = document.createElement("div");
    newComment.classList.add("comment-item");
    newComment.textContent = input;
    commentList.appendChild(newComment);

    document.getElementById("comment-input").value = ""; // Reset input
});

// Simpan progress baca ke server
function saveProgress(user, novel, chapter) {
    fetch("http://localhost:3000/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user, novel, chapter })
    });
}

// Ambil progress baca terakhir
function loadProgress(user, novel) {
    fetch(`http://localhost:3000/progress/${user}/${novel}`)
        .then(response => response.json())
        .then(data => {
            if (data.chapter) {
                alert("Melanjutkan dari Chapter: " + data.chapter);
                window.location.href = `read.html?chapter=${data.chapter}`;
            }
        });
}

// Simpan progress saat chapter dibuka
let currentChapter = "Chapter 1"; // Gantilah dengan data dinamis dari URL
saveProgress("user123", "novelA", currentChapter);


// Simpan progress baca ke server
function saveProgress(user, novel, chapter) {
    fetch("http://localhost:3000/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user, novel, chapter })
    });
}

// Ambil progress baca terakhir
function loadProgress(user, novel) {
    fetch(`http://localhost:3000/progress/${user}/${novel}`)
        .then(response => response.json())
        .then(data => {
            if (data.chapter) {
                alert("Melanjutkan dari Chapter: " + data.chapter);
                window.location.href = `read.html?chapter=${data.chapter}`;
            }
        });
}

// Simpan progress saat chapter dibuka
let currentChapter = "Chapter 1"; // Gantilah dengan data dinamis dari URL
saveProgress("user123", "novelA", currentChapter);

// Ambil komentar dari server
function loadComments(chapter) {
    fetch(`http://localhost:3000/comments/${chapter}`)
        .then(response => response.json())
        .then(comments => {
            let commentList = document.getElementById("comment-list");
            commentList.innerHTML = "";
            comments.forEach(comment => {
                let newComment = document.createElement("div");
                newComment.classList.add("comment-item");
                newComment.textContent = `${comment.user}: ${comment.content}`;
                commentList.appendChild(newComment);
            });
        });
}

// Kirim komentar ke server
document.getElementById("submit-comment").addEventListener("click", function () {
    let input = document.getElementById("comment-input").value;
    if (input.trim() === "") return;

    fetch("http://localhost:3000/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chapter: currentChapter, user: "user123", content: input })
    }).then(() => {
        document.getElementById("comment-input").value = "";
        loadComments(currentChapter);
    });
});

// Muat komentar saat halaman dibuka
loadComments(currentChapter);

document.getElementById("save-bookmark").addEventListener("click", function () {
    let selectedText = window.getSelection().toString();
    if (!selectedText) {
        alert("Pilih teks yang ingin Anda bookmark!");
        return;
    }

    let note = prompt("Tambahkan catatan (opsional):");

    fetch("http://localhost:3000/bookmark", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            user: "user123",
            novel: "novelA",
            chapter: currentChapter,
            text: selectedText,
            note: note || ""
        })
    }).then(() => alert("Bookmark berhasil disimpan!"));
});

function loadBookmarks(user, novel) {
    fetch(`http://localhost:3000/bookmark/${user}/${novel}`)
        .then(response => response.json())
        .then(bookmarks => {
            let bookmarkList = document.createElement("section");
            bookmarkList.innerHTML = "<h2>Bookmark Anda</h2>";

            bookmarks.forEach(bookmark => {
                let item = document.createElement("div");
                item.innerHTML = `<strong>${bookmark.chapter}:</strong> "${bookmark.text}" <br> <em>${bookmark.note}</em>`;
                bookmarkList.appendChild(item);
            });

            document.body.appendChild(bookmarkList);
        });
}

loadBookmarks("user123", "novelA");

let readMode = localStorage.getItem("readMode") || "scroll";
let pages = [];
let currentPage = 0;

// Fungsi untuk membagi teks ke dalam halaman
function splitIntoPages() {
    let content = document.querySelector(".chapter-content");
    let text = content.innerText;
    let words = text.split(" ");
    
    let wordsPerPage = 100; // Sesuaikan jumlah kata per halaman
    pages = [];
    
    for (let i = 0; i < words.length; i += wordsPerPage) {
        let page = document.createElement("div");
        page.classList.add("page");
        page.innerText = words.slice(i, i + wordsPerPage).join(" ");
        content.appendChild(page);
        pages.push(page);
    }

    if (pages.length > 0) {
        pages[0].classList.add("active");
    }
}

// Fungsi untuk mengubah mode baca
function toggleReadMode() {
    if (readMode === "scroll") {
        readMode = "page";
        document.getElementById("toggle-read-mode").textContent = "Mode Scroll";
        splitIntoPages();
    } else {
        readMode = "scroll";
        document.getElementById("toggle-read-mode").textContent = "Mode Halaman";
        document.querySelector(".chapter-content").innerHTML = pages.map(p => p.innerText).join(" ");
    }
    
    localStorage.setItem("readMode", readMode);
}

// Fungsi untuk navigasi halaman dalam mode halaman
function changePage(next = true) {
    if (readMode === "page") {
        pages[currentPage].classList.remove("active");
        currentPage += next ? 1 : -1;
        currentPage = Math.max(0, Math.min(currentPage, pages.length - 1));
        pages[currentPage].classList.add("active");
    }
}

// Event Listener untuk mengganti mode baca
document.getElementById("toggle-read-mode").addEventListener("click", toggleReadMode);

// Tombol navigasi untuk mode halaman
document.getElementById("next-page").addEventListener("click", () => changePage(true));
document.getElementById("prev-page").addEventListener("click", () => changePage(false));

// Cek mode baca saat halaman dimuat
if (readMode === "page") {
    splitIntoPages();
    document.getElementById("toggle-read-mode").textContent = "Mode Scroll";
}

// Cek preferensi dark mode saat halaman dimuat
let isDarkMode = localStorage.getItem("darkMode") === "true";
if (isDarkMode) {
    document.body.classList.add("dark-mode");
    document.getElementById("toggle-dark-mode").textContent = "☀️ Mode Terang";
}

// Tombol untuk mengganti mode gelap
document.getElementById("toggle-dark-mode").addEventListener("click", function () {
    document.body.classList.toggle("dark-mode");
    isDarkMode = document.body.classList.contains("dark-mode");
    localStorage.setItem("darkMode", isDarkMode);
    this.textContent = isDarkMode ? "☀️ Mode Terang" : "🌙 Mode Gelap";
});

// Mengatur ukuran font
let fontSize = parseInt(localStorage.getItem("fontSize")) || 18;
document.querySelector(".chapter-content").style.fontSize = fontSize + "px";

document.getElementById("increase-font").addEventListener("click", function () {
    fontSize += 2;
    document.querySelector(".chapter-content").style.fontSize = fontSize + "px";
    localStorage.setItem("fontSize", fontSize);
});

document.getElementById("decrease-font").addEventListener("click", function () {
    fontSize = Math.max(14, fontSize - 2);
    document.querySelector(".chapter-content").style.fontSize = fontSize + "px";
    localStorage.setItem("fontSize", fontSize);
});

let touchStartX = 0;
let touchEndX = 0;

// Mendeteksi saat pengguna mulai menyentuh layar
document.addEventListener("touchstart", function (event) {
    touchStartX = event.touches[0].clientX;
});

// Mendeteksi saat pengguna selesai menyentuh layar
document.addEventListener("touchend", function (event) {
    touchEndX = event.changedTouches[0].clientX;
    handleSwipe();
});

// Fungsi untuk menentukan arah swipe
function handleSwipe() {
    if (readMode === "page") {
        if (touchStartX - touchEndX > 50) {
            changePage(true); // Swipe kiri (next page)
        } else if (touchEndX - touchStartX > 50) {
            changePage(false); // Swipe kanan (prev page)
        }
    }
}

function changePage(next = true) {
    if (readMode === "page") {
        pages[currentPage].classList.remove("active");
        pages[currentPage].classList.add(next ? "swipe-left" : "swipe-right");

        setTimeout(() => {
            pages[currentPage].classList.remove("swipe-left", "swipe-right");
            currentPage += next ? 1 : -1;
            currentPage = Math.max(0, Math.min(currentPage, pages.length - 1));
            pages[currentPage].classList.add("active");
        }, 300); // Tunggu animasi selesai
    }
}

// Fitur Pencarian Chapter
document.getElementById("search-chapter").addEventListener("input", function () {
    let query = this.value.toLowerCase();
    let chapters = document.querySelectorAll(".chapter-item");
    
    chapters.forEach(chapter => {
        let text = chapter.textContent.toLowerCase();
        chapter.style.display = text.includes(query) ? "block" : "none";
    });
});

// Menandai Chapter yang Sudah Dibaca
let readChapters = JSON.parse(localStorage.getItem("readChapters")) || [];

document.querySelectorAll(".chapter-item").forEach(chapter => {
    let chapterNum = chapter.getAttribute("data-chapter");
    
    if (readChapters.includes(chapterNum)) {
        chapter.classList.add("read");
        chapter.innerHTML = "✔️ " + chapter.textContent;
    }

    chapter.addEventListener("click", function () {
        localStorage.setItem("lastRead", chapterNum);
        if (!readChapters.includes(chapterNum)) {
            readChapters.push(chapterNum);
            localStorage.setItem("readChapters", JSON.stringify(readChapters));
            chapter.classList.add("read");
            chapter.innerHTML = "✔️ " + chapter.textContent;
        }
        window.location.href = `read.html?chapter=${chapterNum}`;
    });
});

document.addEventListener("mouseup", function () {
    let selectedText = window.getSelection().toString().trim();
    if (selectedText) {
        let note = prompt("Tambahkan catatan untuk teks ini:");
        if (note) {
            saveHighlight(selectedText, note);
        }
    }
});

// Simpan highlight & catatan ke localStorage
function saveHighlight(text, note) {
    let highlights = JSON.parse(localStorage.getItem("highlights")) || [];
    highlights.push({ text, note });
    localStorage.setItem("highlights", JSON.stringify(highlights));
    displayHighlights();
}

// Tampilkan highlight & catatan yang tersimpan
function displayHighlights() {
    let highlights = JSON.parse(localStorage.getItem("highlights")) || [];
    let notesList = document.getElementById("notes-list");
    notesList.innerHTML = "";

    highlights.forEach((item, index) => {
        let listItem = document.createElement("li");
        listItem.classList.add("note-item");
        listItem.innerHTML = `<b>"${item.text}"</b>: ${item.note} 
            <button onclick="deleteHighlight(${index})">❌</button>`;
        notesList.appendChild(listItem);
    });
}

// Hapus highlight & catatan
function deleteHighlight(index) {
    let highlights = JSON.parse(localStorage.getItem("highlights")) || [];
    highlights.splice(index, 1);
    localStorage.setItem("highlights", JSON.stringify(highlights));
    displayHighlights();
}

// Tampilkan catatan saat halaman dimuat
window.onload = displayHighlights;

document.getElementById("toggle-mode").addEventListener("click", function () {
    document.body.classList.toggle("dark-mode");
    localStorage.setItem("darkMode", document.body.classList.contains("dark-mode"));
});

// Menyimpan dark mode ketika halaman di-reload
if (localStorage.getItem("darkMode") === "true") {
    document.body.classList.add("dark-mode");
}
function safeAddEventListener(id, event, handler) {
    let element = document.getElementById(id);
    if (element) {
        element.addEventListener(event, handler);
    }
}

safeAddEventListener("toggle-mode", "click", function () {
    document.body.classList.toggle("dark-mode");
    this.textContent = document.body.classList.contains("dark-mode") ? "Mode Terang" : "Mode Gelap";
});

safeAddEventListener("increase-font", "click", function () {
    let content = document.querySelector(".chapter-content");
    if (content) content.style.fontSize = "larger";
});

safeAddEventListener("decrease-font", "click", function () {
    let content = document.querySelector(".chapter-content");
    if (content) content.style.fontSize = "smaller";
});