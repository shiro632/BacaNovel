const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// Koneksi ke MongoDB
mongoose.connect("mongodb://localhost:27017/novelDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Skema untuk progress baca
const ProgressSchema = new mongoose.Schema({
    user: String,
    novel: String,
    chapter: String
});
const Progress = mongoose.model("Progress", ProgressSchema);

// Skema untuk komentar
const CommentSchema = new mongoose.Schema({
    chapter: String,
    user: String,
    content: String,
    timestamp: { type: Date, default: Date.now }
});
const Comment = mongoose.model("Comment", CommentSchema);

// API untuk menyimpan progress baca
app.post("/progress", async (req, res) => {
    const { user, novel, chapter } = req.body;
    await Progress.findOneAndUpdate({ user, novel }, { chapter }, { upsert: true });
    res.send({ message: "Progress disimpan!" });
});

// API untuk mengambil progress baca
app.get("/progress/:user/:novel", async (req, res) => {
    const progress = await Progress.findOne({ user: req.params.user, novel: req.params.novel });
    res.send(progress || { chapter: null });
});

// API untuk menyimpan komentar
app.post("/comments", async (req, res) => {
    const { chapter, user, content } = req.body;
    const newComment = new Comment({ chapter, user, content });
    await newComment.save();
    res.send({ message: "Komentar disimpan!" });
});

// API untuk mengambil komentar berdasarkan chapter
app.get("/comments/:chapter", async (req, res) => {
    const comments = await Comment.find({ chapter: req.params.chapter }).sort({ timestamp: -1 });
    res.send(comments);
});

app.listen(3000, () => console.log("Server berjalan di port 3000"));

// Skema untuk bookmark
const BookmarkSchema = new mongoose.Schema({
    user: String,
    novel: String,
    chapter: String,
    text: String, // Bagian teks yang ditandai
    note: String  // Catatan pengguna
});
const Bookmark = mongoose.model("Bookmark", BookmarkSchema);

// API untuk menyimpan bookmark
app.post("/bookmark", async (req, res) => {
    const { user, novel, chapter, text, note } = req.body;
    const newBookmark = new Bookmark({ user, novel, chapter, text, note });
    await newBookmark.save();
    res.send({ message: "Bookmark disimpan!" });
});

// API untuk mengambil bookmark pengguna
app.get("/bookmark/:user/:novel", async (req, res) => {
    const bookmarks = await Bookmark.find({ user: req.params.user, novel: req.params.novel });
    res.send(bookmarks);
});

const express = require('express');
const app = express();
const port = 3000;

app.get('/progress/:user/:novel/:arc/:chapter', (req, res) => {
  // Simpan progress baca pengguna di database
  res.json({ message: "Progress tersimpan!" });
});

app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});
